  <hr>

  <footer>
    <p>&copy; <?php echo bloginfo('name') . "  20" . date('y') ?></p>
  </footer> 
  
  <?php wp_footer();   ?>
  </body>
</html>