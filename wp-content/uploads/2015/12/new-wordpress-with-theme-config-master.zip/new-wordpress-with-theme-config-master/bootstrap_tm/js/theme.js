var $ = jQuery;

$(document).ready(function(){

  console.log('wayyyyhooooooh!')

})
