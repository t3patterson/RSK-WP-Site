<div class="col-md-3 sidebar">
  <?php if (! dynamic_sidebar('page') ) {  ?>
  <h3>Sidebar Setup</h3>
  <p>Add widgets to sidebar to have them show up</p>
  <p><a href="#" class="btn btn-default">Cool</a></p>
  <?php } ?>
</div>
