<?php 
 $comment_ops =  [
   'comment_field' => '
      <div class="form-group">
        <textarea class="form-control" rows="3"></textarea>
      </div>
   ',

   'class_submit' => 'btn btn-primary'
  ]
?>
